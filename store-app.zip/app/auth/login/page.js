'use client';

import AuthBox from "../components/authBox";

export default function LoginPage(){

    return(
    <>
        <AuthBox/>
    </>
    )

}