'use client';
import { useEffect, useState } from "react";
import ProductCards from "./components/productBoxes";
import { useSession } from "next-auth/react";
import NotLoggedIn from "./components/noAuth/notLoggedin";

export default function ProductPage() {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);

    const {data:session} = useSession();

    useEffect(() => {
        if(session){
            console.log(session);
        fetch('https://dummyjson.com/products')
            .then(res => res.json())
            .then(data => {
                console.log(data);
                setProducts(data.products || []); // Ensure products is an array
                setLoading(false); // Stop loading
            })
            .catch(error => {
                console.error("Error fetching products:", error);
                setLoading(false); // Stop loading on error
            });
        }
    }, []);

    return (
        <>
        {session?
        <div className="container mx-auto py-10 h-min-screen">
            <div className="bg-gray-100 rounded-2xl border-gray-300 border w-full h-full p-5">\
                <h5>{session.user.username}</h5>
                <h1 className="text-center font-normal tracking-widest text-4xl uppercase text-gray-600">
                    Products
                </h1>
                <div className="border-gray-300 border-b w-full my-4"></div>

                {loading ? (
                    <p className="text-center py-5">Loading...</p>
                ) : products.length > 0 ? (
                    <div className="grid lg:grid-cols-4 md:grid-cols-2 sm:grid-cols-1 gap-3">
                        {products.map((product, index) => (
                            <ProductCards
                                title={product.title}
                                sku={product.sku}
                                rating={product.rating}
                                brand={product.brand}
                                thumbnail={product.thumbnail}
                                description={product.description}
                                category={product.category}
                                price={product.price}
                                reviews={product.reviews}
                                key={index}
                            />
                        ))}
                    </div>
                ) : (
                    <p className="text-center py-5">No Data Available</p>
                )}
            </div>
        </div>
        :<NotLoggedIn/>}
        </>
    );
}
