import Link from "next/link";


export default function NotLoggedIn(){
    
    return(<>
        <div className="container mx-auto py-10 h-min-screen">
            <div className="bg-gray-100 rounded-2xl border-gray-300 border w-full h-full p-5">
                <h1 className="text-center font-normal tracking-widest text-4xl uppercase text-gray-600">
                    Products
                </h1>
                
                <h4 className="mt-10 text-center">Please <Link href={'/auth/login'} className="font-semibold">Login</Link> to View products</h4>
                
            </div>
        </div>
    </>)
}