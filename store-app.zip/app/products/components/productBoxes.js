'use client';

import { useState } from "react";
import { IoStar } from "react-icons/io5";


export default function ProductCards({title,sku,rating,brand,thumbnail,description,category,price,reviews}){

    const [modelOpen,setModalOpen] = useState(false);

    const openModal = () =>{ setModalOpen(true)}
    const closeModal = () =>{setModalOpen(false)}

    return(
        <>
            <div onClick={openModal} className="border-gray-300 border bg-white rounded-lg hover:shadow-lg transition-all duration-100 cursor-pointer overflow-hidden">
                    <img className="rounded-t-lg w-full transition duration-300 ease-in-out hover:scale-110" style={{aspectRatio:'16/10',objectFit:'cover'}} src={thumbnail} alt="" />
                    <div className="p-5">
                            <div className="flex row justify-start gap-1">
                                {category?<div className="rounded-full text-sm bg-orange-700 text-white px-3 py-1 capitalize fw-semibold">{category}</div>:''}
                                {brand?<div className="rounded-full text-sm bg-stone-400	 text-white px-3 py-1 capitalize fw-semibold">{brand}</div>:''}
                            </div>
                            <h5 className="mb-2 text-xl font-semibold tracking-tight text-gray-900 mt-4">{title}</h5>
                        <p className="mb-3 font-normal text-gray-700 dark:text-gray-400">{description}</p>
                        <button  className="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-red-500 rounded-lg hover:bg-red-600 hover:text-white focus:ring-4 focus:outline-none focus:ring-blue-300">
                            Read more
                            <svg className="rtl:rotate-180 w-3.5 h-3.5 ms-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M1 5h12m0 0L9 1m4 4L9 9"/>
                            </svg>
                        </button>
                    </div>
            </div>

            {modelOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
                    <div className="bg-white rounded-lg max-w-5xl w-full overflow-hidden">
                    
                        <div className="grid lg:grid-cols-2">
                        <div className="relative">
                            <img
                                className="w-full"
                                src={thumbnail}
                                alt=""
                            />
                            
                        </div>
                        <div className="p-5 relative">
                        <button
                                onClick={closeModal}
                                className="absolute top-4 right-4 bg-gray-800 text-white rounded-full px-2 flex items-center justify-center"
                            >
                                Close
                            </button>
                            <h4 className="text-xl font-normaluppercase">{sku}</h4>
                            <h2 className="text-2xl font-semibold mb-3">{title}</h2>
                            <h3 className="text-2xl font-semibold mb-3">${price} - <span className="text-gray-600 text-lg">Ratings:{rating}</span></h3>
                            <div className="flex gap-2 mb-4">
                                <span className="bg-orange-700 text-white text-sm px-3 py-1 rounded">{category}</span>
                                <span className="bg-stone-400 text-white text-sm px-3 py-1 rounded">{brand}</span>
                            </div>
                            <p className="text-gray-700">{description}</p>
                            
                            <div className="my-5">
                                <h4>Reviews</h4>
                                {reviews.map((review,index)=>(
                                    <div className="w-full bg-gray-100 rounded-lg my-3 p-4" key={index}>
                                        <div className="flex gap-1">
                                            {Array.from({ length: parseInt(review.rating) }, (_, i) => (
                                                <IoStar key={i} className="text-yellow-500" />
                                            ))}
                                        </div>
                                        <p className="text-sm ">"{review.comment}"</p>
                                        <div className="text-end">
                                        <h5 className="text-xl">-{review.reviewerName}</h5>
                                        <h6 className="text-xs">{review.reviewerEmail}</h6>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            )}


        </>
    )

}